public class ChequeMain
{
	public static void main(String[] args) {
		Cheque c = new Cheque();
		c.input();
		c.process();
		c.output();
	}
}